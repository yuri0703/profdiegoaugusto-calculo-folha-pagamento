package main;

import java.util.Scanner;
import funcionario.Funcionario;
public class Main {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Informe o nome do funcionário: ");
        String nome = scanner.nextLine();
        while (!nome.matches("^[a-zA-Z\\s]+$")) { // enquanto o nome não conter apenas letras e espaços em branco
            System.out.print("Nome inválido. Por favor, informe o nome do funcionário: ");
            nome = scanner.nextLine();
        }

        double salarioBruto = -1;
        while (salarioBruto < 0) { // enquanto a entrada não for um número positivo
            System.out.print("Informe o salário bruto do funcionário: ");
            if (scanner.hasNextDouble()) { // se a entrada for um número real
                salarioBruto = scanner.nextDouble();
            } else if (scanner.hasNextInt()) { // se a entrada for um número inteiro
                salarioBruto = scanner.nextInt();
            } else { // se a entrada não for um número válido
                System.out.print("Valor inválido. ");
                scanner.nextLine(); // consome a entrada inválida do scanner
            }
        }
        // verifica se o número é inteiro e converte para inteiro, se for
        if (salarioBruto % 1 == 0) {
            salarioBruto = (int) salarioBruto;
        }

        Funcionario funcionario = new Funcionario(nome, salarioBruto);
        funcionario.calcularSalarioHora();

        System.out.print("O funcionário tem adicional de periculosidade (S/N)? ");
        String resposta = scanner.next();
        if (resposta.equalsIgnoreCase("S")) {
            funcionario.setPericulosidade(true);
            funcionario.calcularPericulosidade();
        }

        System.out.print("O funcionário tem adicional de insalubridade (S/N)? ");
        resposta = scanner.next();
        if (resposta.equalsIgnoreCase("S")) {
            funcionario.setInsalubridade(true);
            funcionario.calcularInsalubridade();
        }

        funcionario.calcularValeTransporte();
        funcionario.calcularValeAlimentacao();
        funcionario.calcularINSS();
        funcionario.calcularFGTS();

        System.out.print("Informe o número de dependentes do funcionário: ");
        int dependentes = scanner.nextInt();
        funcionario.setDependentesIRRF(dependentes);
        funcionario.calcularIRRF();

        funcionario.calcularSalarioLiquido();

        System.out.println(funcionario.gerarRelatorio());
    }
}
